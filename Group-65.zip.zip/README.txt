Group members:
    1. Snehil Jaiswal(2022503)- Raw code 
    2. Arnav Batra(2022)- Debugging

Overview of the implementation:
    This program handles segmentation faults during execution and dynamically allocates memory for the program segments(Pages=4KB=4096).
    The program sets up a signal handler for SIGSEGV (segmentation fault) using the handle_segfault function.
    When a segmentation fault occurs, the handler identifies the faulting address and locates the corresponding program header in the ELF file.
    It then allocates memory for the segment, copies the segment data from the executable file to the allocated memory, and continues execution.

Link to the github repository: https://github.com/snehil1909/OS-SimpleSmartLoader
