#include <stdio.h>
#include <elf.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <signal.h>
#include <stdint.h> // Include this for uintptr_t

// #include "stdint.h"// Include this for uintptr_t

#define PAGE_SIZE 4096

Elf32_Ehdr *ehdr;
Elf32_Phdr *phdr;
int fd;
int page_fault_count = 0;
int page_allocation_count = 0;
double internal_fragmentation = 0;

// Define a function pointer type for _start
typedef int (*_start_fn_type)(void);

// Function to handle segmentation faults
void handle_segfault(int signo, siginfo_t *info, void *context)
{
    // Determine the faulting address
    void *fault_address = info->si_addr;

    printf("fault: %d\n",fault_address);
    // printf("Printing ehdr %d\n", ehdr->e_phnum);

    // Find the program header that corresponds to the faulting address

    lseek(fd,ehdr->e_phoff,SEEK_SET);
    page_fault_count++;
    for (int i = 0; i < ehdr->e_phnum; i++)
    {

        // Elf32_Phdr *p = (Elf32_Phdr *)((char *)ehdr + ehdr->e_phoff + i * ehdr->e_phentsize);
        // printf("%d\n", phdr[i].p_vaddr);
        if ((uintptr_t)fault_address >= (uintptr_t)phdr[i].p_vaddr && (uintptr_t)fault_address < ((uintptr_t)phdr[i].p_vaddr + phdr[i].p_memsz))
        {
            printf("mem: %d\n", phdr[i].p_vaddr);
            // Calculate the page-aligned start and end addresses for the segment
            // void *page_start = (void *)((uintptr_t)phdr->p_vaddr);
            // void *page_end = (void *)(((uintptr_t)phdr->p_memsz));

            // Allocate memory for the entire segment

            int n = 0;
            while(1)
            {
                if(n*4096 >= phdr[i].p_memsz)
                {
                    internal_fragmentation += (4096*n)-phdr[i].p_memsz;
                    break;
                }
                n++;
            }

            page_allocation_count += n;
            void *segment_memory = mmap((void *)phdr[i].p_vaddr, 4096*n, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, 0, 0);

            if (segment_memory == MAP_FAILED)
            {
                perror("Error mapping memory");
                exit(1);
            }

            // Copy the segment data from the executable file to the allocated memory
            lseek(fd, phdr[i].p_offset, SEEK_SET);
            ssize_t bytes_to_copy = phdr[i].p_filesz;
            // if (bytes_to_copy > phdr->p_memsz)
            // {
            //     internal_fragmentation += bytes_to_copy - phdr[i].p_memsz;
            //     bytes_to_copy = phdr[i].p_memsz;
            // }
            if (read(fd, segment_memory, bytes_to_copy) != bytes_to_copy)
            {
                // lseek(fd, phdr[i].p_offset, SEEK_SET);
                // printf("%d %d\n", read(fd, segment_memory, phdr[i].p_filesz), phdr[i].p_memsz);
                perror("Error reading segment data");
                exit(1);
            }
            
            lseek(fd,ehdr->e_phoff,SEEK_SET);

            printf("mmap\n");
            // Continue execution after handling the page fault
            return;
        }
    }

    // If the program header is not found, exit with an error
  
}

int main(int argc, char *argv[])
{
    struct sigaction sa;
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = handle_segfault;
    sigaction(SIGSEGV, &sa, NULL);

    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <executable_file>\n", argv[0]);
        return 1;
    }

    const char *executable_file = argv[1];
    fd = open(executable_file, O_RDONLY);
    if (fd == -1)
    {
        perror("Error opening executable file");
        return 1;
    }

    // Read ELF header
    ehdr = (Elf32_Ehdr *)malloc(sizeof(Elf32_Ehdr));
    if (read(fd, ehdr, sizeof(Elf32_Ehdr)) != sizeof(Elf32_Ehdr))
    {
        printf("Error in reading elf content into memory ... ");
        // loader_cleanup();
        exit(1);
    }

    phdr = (Elf32_Phdr *)malloc(ehdr->e_phentsize * ehdr->e_phnum);
    lseek(fd, ehdr->e_phoff, SEEK_SET);
    int rd = read(fd, phdr, ehdr->e_phentsize * ehdr->e_phnum);

    printf("Printing ehdr %d\n", ehdr->e_phnum);

    // Set up a signal handler for segmentation faults


    // Run the program
    int(*_start) ()= (int (*)())(ehdr->e_entry);
    int result = _start();
    printf("User _start return value = %d\n", result);

    // Report statistics
    printf("Total page faults: %d\n", page_fault_count);
    printf("Total page allocations: %d\n", page_allocation_count);
    printf("Total internal fragmentation (KB): %f\n", internal_fragmentation / 1024);

    // Clean up
    free(ehdr);
    close(fd);
}